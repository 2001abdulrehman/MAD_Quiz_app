package com.example.myquizapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.Drawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.Image;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import android.widget.Toast;

import java.lang.ref.WeakReference;


public class MainActivity extends AppCompatActivity implements SensorEventListener,AdapterView.OnItemSelectedListener {


    private ProgressBar progressBar;

    private TextView textVieww;
    private SensorManager SensorManager;
    private Sensor proximitySensor;   //Proximity_Sensor
    private Boolean isProxSenAvail;
    private Vibrator vibrator;





    static final int REQUEST_CODE_QUIZ = 1;

    //Shared Preferences
    public static final String SHARED_PREFS = "sharedPrefs";  //Shared Preferences
    public static final String KEY_HIGHSCORE = "keyHighscore";

    private TextView textViewHighscore;

    private int highscore;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        progressBar = findViewById(R.id.progress_bar);

//Proximity_Sensor_Vibrator

        textVieww = findViewById(R.id.text_View1);
        SensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (SensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY) != null) {
            proximitySensor = SensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
            isProxSenAvail = true;
        } else {
            textVieww.setText("Proximity Sensor is not availabe");
            isProxSenAvail = false;
        }





        textViewHighscore = findViewById(R.id.text_view_highscore);
        loadHighscore();
    //******
        Button navi = findViewById(R.id.navigation);
        navi.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v)
            {

                gotoNavigation();  //function
            }
        });

    //********

//*********************
        Button services = findViewById(R.id.services);
        services.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View s) {
                startServices();
            }
        });
 //**************
//click button to got to next screen(code)
//***************
        Button buttonStartQuiz = findViewById(R.id.button_start_quiz);
        buttonStartQuiz.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v)
            {

                startQuiz();  //function
            }
        });
//***************

        Spinner spinner = findViewById(R.id.spinner1);  //Spinner adapter
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.numbers, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);


    }



    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }



    //*****

    private void startQuiz() {
        Intent intent = new Intent(MainActivity.this, QuizActivity.class);
        startActivityForResult(intent, REQUEST_CODE_QUIZ);

    }
    //***
    private void startServices(){
        Intent intent = new Intent(MainActivity.this,alarmServices.class);
        startActivityForResult(intent, REQUEST_CODE_QUIZ);

    }

    //*****

    private void gotoNavigation()
    {
        Intent intent = new Intent(MainActivity.this,Navigation.class);
        startActivityForResult(intent,REQUEST_CODE_QUIZ);

    }

    //********

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_QUIZ) {
            if (resultCode == RESULT_OK) {
                int score = data.getIntExtra(QuizActivity.EXTRA_SCORE, 0);
                if (score > highscore) {
                    updateHighscore(score);
                }
            }
        }
    }


    private void loadHighscore() {
        SharedPreferences prefs = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        highscore = prefs.getInt(KEY_HIGHSCORE, 0);
        textViewHighscore.setText("Highscore: " + highscore);
    }

    private void updateHighscore(int highscoreNew)
    {
        highscore = highscoreNew;
        textViewHighscore.setText("Highscore: " + highscore);

        SharedPreferences prefs = getSharedPreferences(SHARED_PREFS, MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putInt(KEY_HIGHSCORE, highscore);
        editor.apply();
    }


//Proximity_Sensor_Vibrator
    @Override
    public void onSensorChanged(SensorEvent sensorEvent)
    {
        textVieww.setText(sensorEvent.values[0] +" ");



        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(500,VibrationEffect.DEFAULT_AMPLITUDE));
        }else
        {
            vibrator.vibrate(500);
            //deprecated in API 26
        }

    }
    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {
    }
    @Override
    protected void onResume()
    {
        super.onResume();
        if(isProxSenAvail)
        {
            SensorManager.registerListener(this,proximitySensor,SensorManager.SENSOR_DELAY_NORMAL);
        }
    }
    @Override
    protected void onPause()
    {
        super.onPause();
        if(isProxSenAvail)
        {
            SensorManager.unregisterListener(this);
        }
    }



}

/*
//setting image
        imageView = findViewById(R.id.imageview1);
                drawable = getResources().getDrawable(R.drawable.img);  //Name of image
                imageView.setImageDrawable(drawable);



ImageView imageView;  //image
    Drawable drawable;


*/
