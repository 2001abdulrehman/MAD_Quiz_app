package com.example.myquizapplication2;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.myquizapplication2.QuizContract.*;  //Accessing all methods from contract class

import java.util.ArrayList;
import java.util.List;

//Sqlite database is just library not (Database)
public class QuizDbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "My_Quiz.db";
    private static final int DATABASE_VERSION = 1;

    private SQLiteDatabase db;

    public QuizDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    //Creating initial database:-
    @Override
    public void onCreate(SQLiteDatabase db) {

        this.db = db;

        final String SQL_CREATE_QUESTIONS_TABLE = "CREATE TABLE " +
                //Accessing all methods and variables from contract class.
                //Giving syntax of table
                QuestionsTable.TABLE_NAME + " ( " +
                QuestionsTable._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                QuestionsTable.COLUMN_QUESTION + " TEXT, " +
                QuestionsTable.COLUMN_OPTION1 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION2 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION3 + " TEXT, " +
                QuestionsTable.COLUMN_OPTION4 + " TEXT, " +
                QuestionsTable.COLUMN_ANSWER_NR + " INTEGER " +
                ")";

        db.execSQL(SQL_CREATE_QUESTIONS_TABLE);
        fillQuestionsTable();

    }

    //onUpgrade()  call
    //Drop table
    //install new version or when database changes then onUpgrade() call
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("Drop Table If Exists " + QuestionsTable.TABLE_NAME);
        onCreate(db);
    }

    private void fillQuestionsTable() {

        Question q1 = new Question("MAD stand for?", "Modern Application development", "Mobile Application development", "Mini Application development", "None of above", 2);
        addQuestion(q1);
        Question q2 = new Question("Which of the following is not a keyword in java ?", "static", "Booleen", "void", "private", 2);
        addQuestion(q2);
        Question q3 = new Question("Who is father of C Programming Language?", "Dennis Ritchie", "Elon Mask", "Henry kelton", "Imran khan", 1);
        addQuestion(q3);
        Question q4 = new Question("What is capital of Pakistan?", "karachi", "Quetta", "Lahore", "Islamabad", 4);
        addQuestion(q4);
        Question q5 = new Question("Who is our National Poet?", "Mirza Ghalib", "Allama-Iqbal", "Syed ahmed khan", "Ch.Rehmat", 2);
        addQuestion(q5);
        Question q6 = new Question("Who is the current federal minister of finance in Pakistan?", "Yousaf", "Ishaq Dar", "Asad Umar", "Bilawal Bhutto", 2);
        addQuestion(q6);
        Question q7 = new Question("Which of the following is a tissue?", "Lungs", "Kidney", "Blood", "Ovary", 3);
        addQuestion(q7);
        Question q8 = new Question("Deficiency of Vitamin-D results in?", "Night blindness", "Hair fall", "Rickets", "None of above", 3);
        addQuestion(q8);
        Question q9 = new Question("The planet that moves round the Sun at the highest speed is?", "Mercury", "Earth", "jupiter", "Mars", 1);
        addQuestion(q9);
        Question q10 = new Question("Which from the following is NOT a conductor?", "Graphite", "Aluminum", "Silicon", "All are conductors", 4);
        addQuestion(q10);


    }

    //Adding Questions to our database
    private void addQuestion(Question question) {

        ContentValues cv = new ContentValues();
        cv.put(QuestionsTable.COLUMN_QUESTION, question.getQuestion());
        cv.put(QuestionsTable.COLUMN_OPTION1, question.getOption1());
        cv.put(QuestionsTable.COLUMN_OPTION2, question.getOption2());
        cv.put(QuestionsTable.COLUMN_OPTION3, question.getOption3());
        cv.put(QuestionsTable.COLUMN_OPTION4, question.getOption4());
        cv.put(QuestionsTable.COLUMN_ANSWER_NR, question.getAnswerNr());

        db.insert(QuestionsTable.TABLE_NAME, null, cv);
    }

    @SuppressLint("Range")
    public List<Question> getAllQuestions() {
        List<Question> questionList = new ArrayList<>();
        db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + QuestionsTable.TABLE_NAME,null);

        if (c.moveToFirst()) {
            do {
                Question question = new Question();
                question.setQuestion(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_QUESTION)));
                question.setOption1(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION1)));
                question.setOption2(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION2)));
                question.setOption3(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION3)));
                question.setOption4(c.getString(c.getColumnIndex(QuestionsTable.COLUMN_OPTION4)));
                question.setAnswerNr(c.getInt(c.getColumnIndex(QuestionsTable.COLUMN_ANSWER_NR)));
                questionList.add(question);
            } while (c.moveToNext());
        }

        c.close();
        return questionList;
    }


}
