package com.example.myquizapplication2;

import static com.example.myquizapplication2.MainActivity.REQUEST_CODE_QUIZ;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class LoginScreen extends AppCompatActivity {

    static final int REQUEST_CODE_QUIZ =1 ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_screen);


        TextView username = (TextView) findViewById(R.id.username);
        TextView password = (TextView) findViewById(R.id.password);

        MaterialButton loginbtn = (MaterialButton) findViewById(R.id.loginbtn);

        //hamza
        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(username.getText().toString().equals("abdulrehman") && password.getText().toString().equals("26027"))
                {
                    //correct
                    Toast.makeText(LoginScreen .this,"Login Successfully",Toast.LENGTH_SHORT).show();
                    startlogin();
                }
                else
                {
                    //incorrect
                    Toast.makeText(LoginScreen.this,"Login Failed!!",Toast.LENGTH_SHORT).show();
                }

            }
        });


    }


    private void startlogin()
    {
        Intent intent = new Intent(LoginScreen.this,MainActivity.class);
        startActivityForResult(intent, REQUEST_CODE_QUIZ);

    }


}
