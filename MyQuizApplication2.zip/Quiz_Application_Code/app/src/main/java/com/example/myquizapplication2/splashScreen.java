package com.example.myquizapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

public class splashScreen extends AppCompatActivity {

    TextView welcome,textAnim;
    //defining time duration:-
    private static int splash_timeout=5000; //5sec


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        welcome = findViewById(R.id.textview11);
        textAnim = findViewById(R.id.textview22);


//Passing intent
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
              Intent splashIntent = new Intent(splashScreen.this,LoginScreen.class);
              startActivity(splashIntent);
              finish();
            }
        },splash_timeout);  //time duration:-

        //text Animation

        Animation myanim = AnimationUtils.loadAnimation(splashScreen.this,R.anim.animation2);
        textAnim.startAnimation(myanim);

        Animation myanim2 = AnimationUtils.loadAnimation(splashScreen.this,R.anim.animation1);
        textAnim.startAnimation(myanim2);



















    }
}